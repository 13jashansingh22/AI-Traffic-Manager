// chart-updates.js - Real-time Chart Updates

class ChartManager {
    constructor() {
        this.charts = {};
        this.history = {
            speed: [],
            queue: [],
            vehicles: [],
            timestamps: []
        };
    }

    // Initialize all charts
    initializeCharts() {
        this.initializeSpeedChart();
        this.initializeQueueChart();
        this.startHistoryUpdates();
    }

    // Initialize speed chart
    initializeSpeedChart() {
        const speedCtx = document.getElementById('speedChart')?.getContext('2d');
        if (!speedCtx) return;

        this.charts.speed = new Chart(speedCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Average Speed (km/h)',
                    data: [],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Average Speed Over Time'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 20,
                        max: 80
                    }
                }
            }
        });
    }

    // Initialize queue chart
    initializeQueueChart() {
        const queueCtx = document.getElementById('queueChart')?.getContext('2d');
        if (!queueCtx) return;

        this.charts.queue = new Chart(queueCtx, {
            type: 'bar',
            data: {
                labels: ['Intersection A', 'Intersection B', 'Intersection C', 'Intersection D'],
                datasets: [{
                    label: 'Queue Length (vehicles)',
                    data: [12, 8, 15, 22],
                    backgroundColor: [
                        '#28a745',
                        '#ffc107',
                        '#fd7e14',
                        '#dc3545'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Current Queue Lengths'
                    }
                }
            }
        });
    }

    // Update charts with new data
    updateCharts(simulationData) {
        this.updateSpeedChart(simulationData);
        this.updateQueueChart(simulationData);
        this.updateHistory(simulationData);
    }

    // Update speed chart
    updateSpeedChart(data) {
        if (!this.charts.speed) return;

        const timestamp = new Date().toLocaleTimeString();
        
        // Add new data point
        this.charts.speed.data.labels.push(timestamp);
        this.charts.speed.data.datasets[0].data.push(data.metrics.avgSpeed);
        
        // Keep only last 20 data points
        if (this.charts.speed.data.labels.length > 20) {
            this.charts.speed.data.labels.shift();
            this.charts.speed.data.datasets[0].data.shift();
        }
        
        this.charts.speed.update('none');
    }

    // Update queue chart
    updateQueueChart(data) {
        if (!this.charts.queue) return;

        const queues = Object.values(data.intersections).map(intersection => intersection.queue);
        this.charts.queue.data.datasets[0].data = queues;
        this.charts.queue.update();
    }

    // Update history data
    updateHistory(data) {
        const timestamp = new Date();
        
        this.history.speed.push(data.metrics.avgSpeed);
        this.history.queue.push(data.metrics.avgQueue);
        this.history.vehicles.push(data.metrics.totalVehicles);
        this.history.timestamps.push(timestamp);
        
        // Keep only last 100 data points
        if (this.history.speed.length > 100) {
            this.history.speed.shift();
            this.history.queue.shift();
            this.history.vehicles.shift();
            this.history.timestamps.shift();
        }
    }

    // Start periodic history updates
    startHistoryUpdates() {
        setInterval(() => {
            if (window.trafficSimulation && window.trafficSimulation.isRunning) {
                this.updateCharts(window.trafficSimulation.getSimulationData());
            }
        }, 2000);
    }

    // Export chart data
    exportChartData() {
        const dataStr = JSON.stringify(this.history, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `traffic-data-${new Date().toISOString()}.json`;
        link.click();
    }
}

// Create global chart manager
window.chartManager = new ChartManager();