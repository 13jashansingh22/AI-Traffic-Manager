// simulation.js - Traffic Simulation Functions

class TrafficSimulation {
    constructor() {
        this.isRunning = false;
        this.simulationInterval = null;
        this.currentTime = 0;
        this.trafficData = {
            intersections: {
                'A': { queue: 12, speed: 45, light: 'red', nextChange: 25 },
                'B': { queue: 8, speed: 52, light: 'green', nextChange: 35 },
                'C': { queue: 15, speed: 38, light: 'yellow', nextChange: 5 },
                'D': { queue: 22, speed: 28, light: 'red', nextChange: 18 }
            },
            metrics: {
                avgQueue: 8.2,
                avgSpeed: 45.6,
                totalVehicles: 156,
                congestion: 'medium'
            }
        };
    }

    // Start the simulation
    startSimulation() {
        if (this.isRunning) {
            console.log('Simulation is already running');
            return;
        }

        this.isRunning = true;
        this.currentTime = 0;
        
        // Update simulation every second
        this.simulationInterval = setInterval(() => {
            this.updateSimulation();
            this.currentTime++;
            
            // Broadcast simulation update
            this.broadcastUpdate();
        }, 1000);

        console.log('Traffic simulation started');
        this.showNotification('Traffic simulation started', 'success');
    }

    // Stop the simulation
    stopSimulation() {
        if (!this.isRunning) {
            console.log('Simulation is not running');
            return;
        }

        this.isRunning = false;
        clearInterval(this.simulationInterval);
        console.log('Traffic simulation stopped');
        this.showNotification('Traffic simulation stopped', 'warning');
    }

    // Update simulation state
    updateSimulation() {
        // Update traffic lights
        this.updateTrafficLights();
        
        // Update vehicle queues
        this.updateVehicleQueues();
        
        // Update metrics
        this.updateMetrics();
        
        // Generate random events
        this.generateRandomEvents();
    }

    // Update traffic light states
    updateTrafficLights() {
        Object.keys(this.trafficData.intersections).forEach(intersection => {
            const data = this.trafficData.intersections[intersection];
            
            // Decrease countdown
            data.nextChange = Math.max(0, data.nextChange - 1);
            
            // Change light when countdown reaches 0
            if (data.nextChange === 0) {
                this.changeTrafficLight(intersection);
            }
        });
    }

    // Change traffic light state
    changeTrafficLight(intersection) {
        const data = this.trafficData.intersections[intersection];
        
        switch (data.light) {
            case 'red':
                data.light = 'green';
                data.nextChange = 30; // Green duration
                break;
            case 'green':
                data.light = 'yellow';
                data.nextChange = 5; // Yellow duration
                break;
            case 'yellow':
                data.light = 'red';
                data.nextChange = 25; // Red duration
                break;
        }
        
        console.log(`Intersection ${intersection} light changed to ${data.light}`);
    }

    // Update vehicle queues based on light states
    updateVehicleQueues() {
        Object.keys(this.trafficData.intersections).forEach(intersection => {
            const data = this.trafficData.intersections[intersection];
            
            if (data.light === 'green') {
                // Vehicles moving - decrease queue
                data.queue = Math.max(0, data.queue - Math.floor(Math.random() * 3));
                data.speed = 40 + Math.random() * 20; // Random speed between 40-60
            } else {
                // Vehicles waiting - increase queue
                data.queue += Math.floor(Math.random() * 2);
                data.speed = 20 + Math.random() * 20; // Lower speed when waiting
            }
        });
    }

    // Update overall metrics
    updateMetrics() {
        const intersections = Object.values(this.trafficData.intersections);
        
        this.trafficData.metrics.avgQueue = intersections.reduce((sum, data) => sum + data.queue, 0) / intersections.length;
        this.trafficData.metrics.avgSpeed = intersections.reduce((sum, data) => sum + data.speed, 0) / intersections.length;
        this.trafficData.metrics.totalVehicles = intersections.reduce((sum, data) => sum + data.queue, 0);
        
        // Update congestion level
        if (this.trafficData.metrics.avgQueue < 5) {
            this.trafficData.metrics.congestion = 'low';
        } else if (this.trafficData.metrics.avgQueue < 15) {
            this.trafficData.metrics.congestion = 'medium';
        } else {
            this.trafficData.metrics.congestion = 'high';
        }
    }

    // Generate random traffic events
    generateRandomEvents() {
        // 5% chance of a random event each second
        if (Math.random() < 0.05) {
            const events = [
                'accident',
                'road_closure', 
                'congestion',
                'clear'
            ];
            
            const randomEvent = events[Math.floor(Math.random() * events.length)];
            this.handleRandomEvent(randomEvent);
        }
    }

    // Handle random events
    handleRandomEvent(event) {
        const intersections = Object.keys(this.trafficData.intersections);
        const randomIntersection = intersections[Math.floor(Math.random() * intersections.length)];
        
        switch (event) {
            case 'accident':
                this.trafficData.intersections[randomIntersection].queue += 10;
                this.showAlert(`Accident reported at Intersection ${randomIntersection}`, 'danger');
                break;
            case 'road_closure':
                this.trafficData.intersections[randomIntersection].queue += 15;
                this.showAlert(`Road closure at Intersection ${randomIntersection}`, 'warning');
                break;
            case 'congestion':
                this.trafficData.intersections[randomIntersection].queue += 8;
                this.showAlert(`Heavy congestion at Intersection ${randomIntersection}`, 'warning');
                break;
            case 'clear':
                this.trafficData.intersections[randomIntersection].queue = Math.max(0, this.trafficData.intersections[randomIntersection].queue - 5);
                this.showAlert(`Traffic clearing at Intersection ${randomIntersection}`, 'success');
                break;
        }
    }

    // Manual override for traffic lights
    manualOverride(intersection, light) {
        if (this.trafficData.intersections[intersection]) {
            this.trafficData.intersections[intersection].light = light;
            this.trafficData.intersections[intersection].nextChange = 30; // Reset timer
            
            console.log(`Manual override: Intersection ${intersection} set to ${light}`);
            this.showNotification(`Intersection ${intersection} manually set to ${light}`, 'info');
            
            this.broadcastUpdate();
        }
    }

    // Emergency override - set all to red
    emergencyOverride() {
        Object.keys(this.trafficData.intersections).forEach(intersection => {
            this.trafficData.intersections[intersection].light = 'red';
            this.trafficData.intersections[intersection].nextChange = 999; // Long duration
        });
        
        console.log('Emergency override activated - all lights set to red');
        this.showNotification('Emergency override activated! All lights set to red.', 'danger');
        this.broadcastUpdate();
    }

    // Get current simulation data
    getSimulationData() {
        return {
            ...this.trafficData,
            isRunning: this.isRunning,
            currentTime: this.currentTime
        };
    }

    // Broadcast updates to UI
    broadcastUpdate() {
        // Dispatch custom event for UI updates
        const event = new CustomEvent('simulationUpdate', {
            detail: this.getSimulationData()
        });
        window.dispatchEvent(event);
    }

    // Show notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${this.getIconForType(type)}"></i>
            <div>${message}</div>
        `;
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '1000';
        notification.style.minWidth = '300px';
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    // Show alert in alerts section
    showAlert(message, type = 'warning') {
        const alertsSection = document.querySelector('.alerts-section');
        if (alertsSection) {
            const alert = document.createElement('div');
            alert.className = `alert ${type}`;
            alert.innerHTML = `
                <i class="fas fa-${this.getIconForType(type)}"></i>
                <div>${message}</div>
            `;
            alertsSection.appendChild(alert);
            
            // Remove after 10 seconds
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 10000);
        }
    }

    getIconForType(type) {
        const icons = {
            'success': 'check-circle',
            'warning': 'exclamation-triangle',
            'danger': 'times-circle',
            'info': 'info-circle'
        };
        return icons[type] || 'info-circle';
    }
}

// Create global simulation instance
window.trafficSimulation = new TrafficSimulation();