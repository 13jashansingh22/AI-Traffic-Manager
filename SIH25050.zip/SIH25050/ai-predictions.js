// ai-predictions.js - AI Prediction and RL Agent Functions

class TrafficAI {
    constructor() {
        this.modelLoaded = false;
        this.predictions = {};
        this.history = [];
    }

    // Initialize AI model
    async initializeModel() {
        // Simulate model loading
        return new Promise((resolve) => {
            setTimeout(() => {
                this.modelLoaded = true;
                console.log('Traffic AI model initialized');
                resolve();
            }, 2000);
        });
    }

    // Get traffic prediction
    async getPrediction(intersection = 'all') {
        if (!this.modelLoaded) {
            await this.initializeModel();
        }

        // Simulate AI prediction
        return new Promise((resolve) => {
            setTimeout(() => {
                const prediction = this.generatePrediction(intersection);
                this.predictions[intersection] = prediction;
                this.history.push({
                    timestamp: new Date(),
                    intersection,
                    prediction
                });
                
                resolve(prediction);
            }, 1000);
        });
    }

    // Generate simulated prediction
    generatePrediction(intersection) {
        const predictions = {
            traffic_flow: Math.random() > 0.3 ? 'improving' : 'worsening',
            improvement_rate: (10 + Math.random() * 20).toFixed(1) + '%',
            recommended_action: this.getRecommendedAction(),
            confidence: (70 + Math.random() * 25).toFixed(1) + '%',
            timeframe: '5-10 minutes',
            details: this.getPredictionDetails()
        };

        return predictions;
    }

    // Get RL agent recommendation
    getRecommendedAction() {
        const actions = [
            'Increase green light duration by 15 seconds',
            'Decrease green light duration by 10 seconds',
            'Prioritize north-bound traffic',
            'Prioritize east-bound traffic',
            'Implement wave-based timing',
            'No change needed - current timing optimal'
        ];
        return actions[Math.floor(Math.random() * actions.length)];
    }

    // Get prediction details
    getPredictionDetails() {
        const details = [
            'Traffic flow expected to improve due to reduced incoming vehicles',
            'Heavy congestion predicted in commercial district',
            'School zone traffic will decrease in 15 minutes',
            'Rush hour patterns detected - adjust timing accordingly',
            'Weather conditions may affect traffic patterns'
        ];
        return details[Math.floor(Math.random() * details.length)];
    }

    // Apply AI suggestion
    applySuggestion(suggestion) {
        console.log('Applying AI suggestion:', suggestion);
        
        // Parse suggestion and apply to simulation
        if (suggestion.includes('Increase green light')) {
            this.applyGreenLightIncrease(suggestion);
        } else if (suggestion.includes('Decrease green light')) {
            this.applyGreenLightDecrease(suggestion);
        } else if (suggestion.includes('Prioritize')) {
            this.applyTrafficPriority(suggestion);
        }
        
        this.showNotification(`AI suggestion applied: ${suggestion}`, 'success');
    }

    applyGreenLightIncrease(suggestion) {
        // Extract duration from suggestion
        const durationMatch = suggestion.match(/(\d+)\s*seconds?/);
        const duration = durationMatch ? parseInt(durationMatch[1]) : 15;
        
        // Apply to simulation
        // This would interface with the traffic simulation
        console.log(`Increasing green light duration by ${duration} seconds`);
    }

    applyGreenLightDecrease(suggestion) {
        const durationMatch = suggestion.match(/(\d+)\s*seconds?/);
        const duration = durationMatch ? parseInt(durationMatch[1]) : 10;
        
        console.log(`Decreasing green light duration by ${duration} seconds`);
    }

    applyTrafficPriority(suggestion) {
        const directionMatch = suggestion.match(/(north|south|east|west)-bound/);
        const direction = directionMatch ? directionMatch[1] : 'north';
        
        console.log(`Prioritizing ${direction}-bound traffic`);
    }

    // Get prediction history
    getPredictionHistory() {
        return this.history.slice(-10); // Last 10 predictions
    }

    // Show notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert ${type}`;
        notification.innerHTML = `
            <i class="fas fa-robot"></i>
            <div>${message}</div>
        `;
        notification.style.position = 'fixed';
        notification.style.top = '80px';
        notification.style.right = '20px';
        notification.style.zIndex = '1000';
        notification.style.minWidth = '300px';
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 4000);
    }
}

// Create global AI instance
window.trafficAI = new TrafficAI();